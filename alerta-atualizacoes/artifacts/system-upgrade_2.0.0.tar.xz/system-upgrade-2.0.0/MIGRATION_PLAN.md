# Plano de migracao para Qt 6

## Objetivo

Transformar `system-upgrade` em uma aplicacao Qt 6 nativa para Plasma/Wayland que verifica atualizacoes de forma assincorna, informa o usuario e abre o Discover para instalacao, sem executar a GUI como root.

## Correspondencia legado -> novo

- `system-upgrade` Bash -> binario C++/Qt 6 `system-upgrade`.
- YAD dialogs -> janela Qt Widgets e notificacoes Plasma via KF6 KNotifications.
- `sudo /usr/bin/system-upgrade-exe` -> PackageKitQt6 via D-Bus/PolicyKit.
- Parsing de `apt-get dist-upgrade --assume-no` -> `PackageKit::Daemon::getUpdates()`.
- `apt-get update` -> `PackageKit::Daemon::refreshCache(false)` quando solicitado, respeitando politica e locks do sistema.
- `plasma-discover --mode=Update` -> `QProcess::startDetached("plasma-discover", {"--mode=Update"})`.
- XDG Autostart legado -> XDG Autostart com `system-upgrade --background`.
- `/tmp/system-update` -> nenhum arquivo temporario global.
- sudoers NOPASSWD -> removido.

## Arquitetura

- `main.cpp`: bootstrap Qt, parser de argumentos, single-instance e selecao de modo.
- `SingleInstance`: `QLockFile` + `QLocalServer` para evitar multiplas instancias e ativar a primeira.
- `PackageKitBackend`: backend assincorno PackageKitQt6; coleta pacotes e mapeia erros/locks/rede para estados de UI.
- `UpdateTypes`: tipos e funcoes puras para estados, textos e classificacao testavel.
- `MainWindow`: interface Qt Widgets responsiva.
- `TrayController`: StatusNotifierItem nativo do KDE para Plasma/Wayland.
- `NotificationService`: KNotifications com acao para abrir Discover.

## PackageKit/APT

PackageKit e a interface principal porque:

- e assincorno por D-Bus;
- integra com PolicyKit;
- evita parsing de saida humana;
- respeita locks e operacoes simultaneas;
- e o backend esperado por Discover no Plasma.

APT/dpkg nao serao chamados diretamente pela GUI. Caso PackageKit reporte indisponibilidade, lock, rede ausente ou erro, isso sera exibido/registrado sem tentar quebrar locks.

## Privilegios

A GUI sempre roda como usuario normal. A aplicacao nao usa `sudo` nem `pkexec`. A instalacao real e delegada ao Discover/PackageKit, que aplica PolicyKit no escopo da operacao privilegiada.

## Plasma/Wayland

Qt Widgets funciona nativamente no Wayland via Qt 6. O tray usa `KStatusNotifierItem`, que implementa a especificacao D-Bus StatusNotifier usada pelo Plasma 6, evitando dependencia de X11. Notificacoes usam KNotifications.

## Autostart

O pacote instala `/etc/xdg/autostart/system-upgrade.desktop` com `Exec=system-upgrade --background`. Esse modo verifica atualizacoes sem abrir janela imediatamente. Sem atualizacoes, encerra. Com atualizacoes, mostra notificacao e disponibiliza um item de status para abrir o Discover.

## Testes

A logica pura de estados e resumo sera coberta com Qt Test. Os testes nao executam transacoes reais nem alteram o sistema. Cenarios cobertos:

- nenhuma atualizacao;
- atualizacoes disponiveis;
- backend indisponivel;
- falha de rede;
- operacao em andamento;
- erro inesperado;
- resposta vazia;
- cancelamento.

## Empacotamento

O pacote fonte Debian passa a usar `debian/` com debhelper e CMake. O nome binario permanece `system-upgrade` para compatibilidade com launchers e upgrades. O pacote remove a regra sudoers antiga por nao instala-la mais; em upgrade, arquivos obsoletos gerenciados pelo dpkg sao substituidos/removidos conforme o pacote novo. Como a versao 1.0.4 instalava o autostart sob `/etc` sem registra-lo como conffile, um `preinst` remove somente a copia legada inalterada, validada pelo checksum original. Arquivos modificados pelo administrador sao preservados.

## Riscos residuais

- A disponibilidade de detalhes como tamanho total de download depende do backend PackageKit.
- Flatpak era parcialmente consultado pelo helper antigo, mas o resultado nao era usado pela UI; nao sera reimplementado como comportamento proprio. Ao abrir o Discover, atualizacoes Flatpak continuam sob responsabilidade do Discover/PackageKit/plugins instalados.
- A integracao visual e a ativacao do StatusNotifierItem ainda precisam de um ensaio em uma sessao Plasma Wayland real; a sandbox usada na migracao nao expoe o compositor nem o barramento de sessao do usuario.
