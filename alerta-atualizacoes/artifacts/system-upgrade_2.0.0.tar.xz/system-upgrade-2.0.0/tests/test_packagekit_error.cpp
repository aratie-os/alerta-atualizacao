#include "packagekit_error.h"

#include <QTest>

class PackageKitErrorTest final : public QObject
{
    Q_OBJECT

private slots:
    void mapsErrors_data();
    void mapsErrors();
};

void PackageKitErrorTest::mapsErrors_data()
{
    using Error = PackageKit::Transaction::Error;
    QTest::addColumn<Error>("error");
    QTest::addColumn<UpdateStatus>("expected");

    QTest::newRow("empty update set") << Error::ErrorNoPackagesToUpdate
                                      << UpdateStatus::NoUpdates;
    QTest::newRow("network unavailable") << Error::ErrorNoNetwork
                                          << UpdateStatus::NetworkUnavailable;
    QTest::newRow("repository unavailable") << Error::ErrorRepoNotAvailable
                                             << UpdateStatus::NetworkUnavailable;
    QTest::newRow("package manager locked") << Error::ErrorCannotGetLock
                                             << UpdateStatus::Busy;
    QTest::newRow("unfinished transaction") << Error::ErrorUnfinishedTransaction
                                             << UpdateStatus::Busy;
    QTest::newRow("daemon unavailable") << Error::ErrorFailedInitialization
                                         << UpdateStatus::BackendUnavailable;
    QTest::newRow("unsupported backend") << Error::ErrorNotSupported
                                          << UpdateStatus::BackendUnavailable;
    QTest::newRow("cancelled") << Error::ErrorTransactionCancelled
                                << UpdateStatus::Cancelled;
    QTest::newRow("unexpected") << Error::ErrorGpgFailure << UpdateStatus::Error;
}

void PackageKitErrorTest::mapsErrors()
{
    QFETCH(PackageKit::Transaction::Error, error);
    QFETCH(UpdateStatus, expected);
    QCOMPARE(packageKitErrorStatus(error), expected);
}

QTEST_GUILESS_MAIN(PackageKitErrorTest)

#include "test_packagekit_error.moc"
