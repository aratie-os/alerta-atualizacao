#include "update_types.h"

#include <QTest>

class UpdateTypesTest final : public QObject
{
    Q_OBJECT

private slots:
    void emptyResponseMeansNoUpdates();
    void packagesMeanUpdatesAvailable();
    void errorStatesArePreserved_data();
    void errorStatesArePreserved();
    void transientStatesAreNotTerminal();
};

void UpdateTypesTest::emptyResponseMeansNoUpdates()
{
    const UpdateResult result = resultForPackages({});
    QCOMPARE(result.status, UpdateStatus::NoUpdates);
    QVERIFY(result.packages.isEmpty());
    QVERIFY(result.checkedAt.isValid());
    QVERIFY(!hasAvailableUpdates(result));
}

void UpdateTypesTest::packagesMeanUpdatesAvailable()
{
    PackageUpdate package;
    package.packageId = QStringLiteral("example;2.0;amd64;updates");
    package.name = QStringLiteral("example");
    package.version = QStringLiteral("2.0");
    package.architecture = QStringLiteral("amd64");

    const UpdateResult result = resultForPackages({package});
    QCOMPARE(result.status, UpdateStatus::UpdatesAvailable);
    QCOMPARE(result.packages.size(), 1);
    QVERIFY(hasAvailableUpdates(result));
}

void UpdateTypesTest::errorStatesArePreserved_data()
{
    QTest::addColumn<UpdateStatus>("status");
    QTest::newRow("backend unavailable") << UpdateStatus::BackendUnavailable;
    QTest::newRow("network failure") << UpdateStatus::NetworkUnavailable;
    QTest::newRow("operation busy") << UpdateStatus::Busy;
    QTest::newRow("unexpected error") << UpdateStatus::Error;
    QTest::newRow("cancelled") << UpdateStatus::Cancelled;
}

void UpdateTypesTest::errorStatesArePreserved()
{
    QFETCH(UpdateStatus, status);
    const UpdateResult result = errorResult(status, QStringLiteral("diagnostic"));
    QCOMPARE(result.status, status);
    QCOMPARE(result.details, QStringLiteral("diagnostic"));
    QVERIFY(isTerminalStatus(result.status));
    QVERIFY(!hasAvailableUpdates(result));
}

void UpdateTypesTest::transientStatesAreNotTerminal()
{
    QVERIFY(!isTerminalStatus(UpdateStatus::Idle));
    QVERIFY(!isTerminalStatus(UpdateStatus::RefreshingCache));
    QVERIFY(!isTerminalStatus(UpdateStatus::Checking));
}

QTEST_GUILESS_MAIN(UpdateTypesTest)

#include "test_update_types.moc"
