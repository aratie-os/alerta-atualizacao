# System Upgrade

`system-upgrade` e um verificador de atualizacoes nativo para KDE Plasma. Ele
consulta o PackageKit de forma assincrona, exibe os pacotes disponiveis em uma
interface Qt 6, envia notificacoes do Plasma e abre o Discover para instalar as
atualizacoes.

A versao 2.0 substitui integralmente os scripts Bash/YAD do pacote 1.0.4. A GUI
sempre roda como usuario comum: nao usa `sudo`, `pkexec`, parsing da saida do APT,
arquivos globais em `/tmp` ou manipulacao de locks.

## Arquitetura

- `PackageKitBackend`: transacoes assicronas de refresh e consulta via
  PackageKitQt6/D-Bus.
- `MainWindow`: interface Qt Widgets adaptada ao tema, fontes e escala do Plasma.
- `NotificationService`: notificacoes KNotifications com acoes.
- `TrayController`: StatusNotifierItem D-Bus compativel com Plasma Wayland.
- `SingleInstance`: lock por usuario e ativacao da instancia existente por socket
  local restrito ao usuario, com recuperacao automatica de lock obsoleto.
- `UpdateTypes`: modelo de estados independente e coberto por Qt Test.

O Discover continua sendo responsavel pela instalacao. Assim, autorizacao e
operacoes privilegiadas ficam no fluxo PackageKit/PolicyKit mantido pelo desktop.

## Dependencias

No Kubuntu 26.04:

```sh
sudo apt install build-essential cmake qt6-base-dev \
  libpackagekitqt6-dev extra-cmake-modules libkf6notifications-dev \
  libkf6statusnotifieritem-dev debhelper devscripts lintian \
  desktop-file-utils appstream
```

Em tempo de execucao sao necessarios `packagekit` e `plasma-discover`; as demais
bibliotecas sao resolvidas automaticamente pelo pacote Debian.

## Compilacao e execucao

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build --parallel
./build/system-upgrade --gui
```

Opcoes relevantes:

- `--gui`: abre a janela e verifica imediatamente.
- `--background`: verifica sem abrir a janela; notifica apenas quando necessario.
- `--no-refresh`: consulta o cache atual sem atualizar os metadados primeiro.

## Testes

```sh
ctest --test-dir build --output-on-failure
```

Os testes cobrem classificacao de resposta vazia, atualizacoes disponiveis,
backend indisponivel, rede, operacao ocupada, erro inesperado e cancelamento. Eles
nao alteram pacotes do sistema.

## Pacote Debian

```sh
dpkg-buildpackage -us -uc
lintian ../system-upgrade_2.0.0_amd64.changes
sudo apt install ../system-upgrade_2.0.0_amd64.deb
```

Remocao:

```sh
sudo apt remove system-upgrade
```

Use `sudo apt purge system-upgrade` para remover tambem o arquivo de autostart
tratado como configuracao pelo dpkg.

O pacote instala o binario, um launcher, um XDG Autostart e metadados AppStream.
Um `preinst` estritamente delimitado remove, durante upgrade, apenas o autostart
1.0.4 inalterado identificado por checksum; isso evita uma pergunta de conffile.
O pacote nao instala helper privilegiado nem regra sudoers.

## Diagnostico

Execute pelo terminal para consultar as categorias de log Qt:

```sh
QT_LOGGING_RULES='system-upgrade.*=true' system-upgrade --gui
```

Transacoes e erros do daemon tambem podem ser examinados com:

```sh
journalctl --user --since today | grep system-upgrade
journalctl -u packagekit --since today
```

## Estrutura

- `src/`: aplicacao e integracoes Qt/KDE/PackageKit.
- `tests/`: testes unitarios Qt Test.
- `data/`: arquivos desktop, autostart e AppStream.
- `debian/`: empacotamento fonte Debian.
- `legacy/original-package/`: pacote 1.0.4 extraido e arquivos originais.
- `AUDIT.md`: auditoria tecnica da implementacao anterior.
- `MIGRATION_PLAN.md`: decisoes e correspondencia da migracao.
