#include "packagekit_error.h"

UpdateStatus packageKitErrorStatus(PackageKit::Transaction::Error error)
{
    using Error = PackageKit::Transaction::Error;
    switch (error) {
    case Error::ErrorNoPackagesToUpdate:
        return UpdateStatus::NoUpdates;
    case Error::ErrorNoNetwork:
    case Error::ErrorRepoNotAvailable:
    case Error::ErrorNoMoreMirrorsToTry:
        return UpdateStatus::NetworkUnavailable;
    case Error::ErrorCannotGetLock:
    case Error::ErrorLockRequired:
    case Error::ErrorUnfinishedTransaction:
    case Error::ErrorUpdateFailedDueToRunningProcess:
        return UpdateStatus::Busy;
    case Error::ErrorTransactionCancelled:
    case Error::ErrorCancelledPriority:
        return UpdateStatus::Cancelled;
    case Error::ErrorNotSupported:
    case Error::ErrorInternalError:
    case Error::ErrorFailedInitialization:
        return UpdateStatus::BackendUnavailable;
    default:
        return UpdateStatus::Error;
    }
}
