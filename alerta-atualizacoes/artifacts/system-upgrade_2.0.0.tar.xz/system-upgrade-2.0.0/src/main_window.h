#pragma once

#include "update_types.h"

#include <QMainWindow>

class QLabel;
class QProgressBar;
class QPushButton;
class QTableWidget;

class MainWindow final : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

public slots:
    void showAndActivate();
    void setBusyState(UpdateStatus status, const QString &details);
    void setResult(const UpdateResult &result);

signals:
    void checkRequested(bool refreshCache);
    void cancelRequested();
    void openDiscoverRequested();

private:
    void populatePackages(const QVector<PackageUpdate> &packages);
    void updateControls(bool busy, bool updatesAvailable);

    QLabel *m_iconLabel = nullptr;
    QLabel *m_titleLabel = nullptr;
    QLabel *m_descriptionLabel = nullptr;
    QLabel *m_lastCheckedLabel = nullptr;
    QProgressBar *m_progress = nullptr;
    QTableWidget *m_table = nullptr;
    QPushButton *m_checkButton = nullptr;
    QPushButton *m_cancelButton = nullptr;
    QPushButton *m_discoverButton = nullptr;
};
