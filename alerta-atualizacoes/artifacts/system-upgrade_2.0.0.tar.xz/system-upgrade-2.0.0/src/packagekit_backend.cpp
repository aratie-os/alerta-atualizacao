#include "packagekit_backend.h"

#include "packagekit_error.h"

#include <PackageKit/daemon.h>
#include <PackageKit/transaction.h>

#include <QLoggingCategory>

Q_LOGGING_CATEGORY(logPackageKit, "system-upgrade.packagekit")

namespace {
bool isSecurityUpdate(PackageKit::Transaction::Info info)
{
    using Info = PackageKit::Transaction::Info;
    return info == Info::InfoSecurity || info == Info::InfoImportant || info == Info::InfoCritical;
}
}

PackageKitBackend::PackageKitBackend(QObject *parent)
    : QObject(parent)
{
    qRegisterMetaType<UpdateResult>();
    qRegisterMetaType<UpdateStatus>();
}

bool PackageKitBackend::isRunning() const
{
    return m_transaction != nullptr;
}

void PackageKitBackend::checkForUpdates(bool refreshCache)
{
    if (isRunning()) {
        emit stateChanged(UpdateStatus::Busy, tr("Uma verificação já está em andamento."));
        return;
    }

    m_packages.clear();
    m_errorDetails.clear();
    m_errorStatus = UpdateStatus::Error;

    if (PackageKit::Daemon::networkState() == PackageKit::Daemon::NetworkOffline) {
        finishWithError(UpdateStatus::NetworkUnavailable, {});
        return;
    }
    if (PackageKit::Daemon::locked()) {
        finishWithError(UpdateStatus::Busy, {});
        return;
    }

    if (refreshCache) {
        startRefresh();
    } else {
        startQuery();
    }
}

void PackageKitBackend::cancel()
{
    if (!m_transaction) {
        return;
    }
    if (m_transaction->allowCancel()) {
        m_transaction->cancel();
    }
}

void PackageKitBackend::startRefresh()
{
    emit stateChanged(UpdateStatus::RefreshingCache, {});
    auto *transaction = PackageKit::Daemon::refreshCache(false);
    if (!transaction) {
        finishWithError(UpdateStatus::BackendUnavailable,
                        tr("O PackageKit não conseguiu criar uma transação de atualização."));
        return;
    }
    m_transaction = transaction;
    attachCommonSignals(transaction, Operation::Refresh);
}

void PackageKitBackend::startQuery()
{
    emit stateChanged(UpdateStatus::Checking, {});
    auto *transaction = PackageKit::Daemon::getUpdates(PackageKit::Transaction::FilterNone);
    if (!transaction) {
        finishWithError(UpdateStatus::BackendUnavailable,
                        tr("O PackageKit não conseguiu criar uma consulta de atualizações."));
        return;
    }
    m_transaction = transaction;
    attachCommonSignals(transaction, Operation::Query);

    connect(transaction,
            &PackageKit::Transaction::package,
            this,
            [this](PackageKit::Transaction::Info info,
                   const QString &packageId,
                   const QString &summary) {
                PackageUpdate update;
                update.packageId = packageId;
                update.name = PackageKit::Daemon::packageName(packageId);
                update.version = PackageKit::Daemon::packageVersion(packageId);
                update.architecture = PackageKit::Daemon::packageArch(packageId);
                update.summary = summary;
                update.security = isSecurityUpdate(info);
                m_packages.push_back(std::move(update));
            });
}

void PackageKitBackend::attachCommonSignals(PackageKit::Transaction *transaction,
                                             Operation operation)
{
    connect(transaction,
            &PackageKit::Transaction::statusChanged,
            this,
            [this, transaction] {
                if (transaction->status() == PackageKit::Transaction::StatusWaitingForLock) {
                    emit stateChanged(UpdateStatus::Busy,
                                      tr("Aguardando outra operação do gerenciador de pacotes."));
                }
            });

    connect(transaction,
            &PackageKit::Transaction::errorCode,
            this,
            [this](PackageKit::Transaction::Error error, const QString &details) {
                m_errorStatus = packageKitErrorStatus(error);
                m_errorDetails = details.simplified();
                qCWarning(logPackageKit) << "PackageKit error" << error << m_errorDetails;
            });

    connect(transaction,
            &PackageKit::Transaction::finished,
            this,
            [this, operation](PackageKit::Transaction::Exit exitStatus, uint) {
                clearTransaction();

                if (exitStatus == PackageKit::Transaction::ExitSuccess) {
                    if (operation == Operation::Refresh) {
                        startQuery();
                    } else {
                        emit resultReady(resultForPackages(std::move(m_packages)));
                    }
                    return;
                }

                if (exitStatus == PackageKit::Transaction::ExitCancelled
                    || exitStatus == PackageKit::Transaction::ExitCancelledPriority) {
                    finishWithError(UpdateStatus::Cancelled, m_errorDetails);
                    return;
                }
                finishWithError(m_errorStatus, m_errorDetails);
            });
}

void PackageKitBackend::finishWithError(UpdateStatus status, const QString &details)
{
    clearTransaction();
    emit resultReady(errorResult(status, details));
}

void PackageKitBackend::clearTransaction()
{
    m_transaction.clear();
}
