#include "main_window.h"

#include <QDateTime>
#include <QHeaderView>
#include <QIcon>
#include <QLabel>
#include <QLocale>
#include <QProgressBar>
#include <QPushButton>
#include <QStyle>
#include <QTableWidget>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle(tr("Atualizações do sistema"));
    setWindowIcon(QIcon::fromTheme(QStringLiteral("system-software-update")));
    resize(760, 480);
    setMinimumSize(520, 360);

    auto *central = new QWidget(this);
    auto *rootLayout = new QVBoxLayout(central);
    rootLayout->setContentsMargins(20, 20, 20, 16);
    rootLayout->setSpacing(12);

    auto *headerLayout = new QHBoxLayout;
    m_iconLabel = new QLabel(central);
    m_iconLabel->setPixmap(QIcon::fromTheme(QStringLiteral("system-software-update"))
                               .pixmap(style()->pixelMetric(QStyle::PM_LargeIconSize)));
    m_iconLabel->setAlignment(Qt::AlignTop);

    auto *textLayout = new QVBoxLayout;
    textLayout->setSpacing(4);
    m_titleLabel = new QLabel(updateStatusTitle(UpdateStatus::Idle), central);
    QFont titleFont = m_titleLabel->font();
    titleFont.setBold(true);
    titleFont.setPointSizeF(titleFont.pointSizeF() + 2.0);
    m_titleLabel->setFont(titleFont);
    m_descriptionLabel = new QLabel(updateStatusDescription(UpdateResult{}), central);
    m_descriptionLabel->setWordWrap(true);
    textLayout->addWidget(m_titleLabel);
    textLayout->addWidget(m_descriptionLabel);
    headerLayout->addWidget(m_iconLabel);
    headerLayout->addLayout(textLayout, 1);
    rootLayout->addLayout(headerLayout);

    m_progress = new QProgressBar(central);
    m_progress->setRange(0, 0);
    m_progress->setTextVisible(false);
    m_progress->hide();
    rootLayout->addWidget(m_progress);

    m_table = new QTableWidget(central);
    m_table->setColumnCount(4);
    m_table->setHorizontalHeaderLabels(
        {tr("Pacote"), tr("Versão"), tr("Arquitetura"), tr("Descrição")});
    m_table->setAlternatingRowColors(true);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->verticalHeader()->hide();
    m_table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
    m_table->hide();
    rootLayout->addWidget(m_table, 1);

    m_lastCheckedLabel = new QLabel(central);
    m_lastCheckedLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    rootLayout->addWidget(m_lastCheckedLabel);

    auto *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch();
    m_cancelButton = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-cancel")),
                                     tr("Cancelar"), central);
    m_cancelButton->hide();
    m_checkButton = new QPushButton(QIcon::fromTheme(QStringLiteral("view-refresh")),
                                    tr("Verificar agora"), central);
    m_checkButton->setDefault(true);
    m_discoverButton = new QPushButton(QIcon::fromTheme(QStringLiteral("plasmadiscover")),
                                       tr("Abrir Discover"), central);
    m_discoverButton->hide();
    buttonLayout->addWidget(m_cancelButton);
    buttonLayout->addWidget(m_checkButton);
    buttonLayout->addWidget(m_discoverButton);
    rootLayout->addLayout(buttonLayout);

    setCentralWidget(central);

    connect(m_checkButton, &QPushButton::clicked, this, [this] { emit checkRequested(true); });
    connect(m_cancelButton, &QPushButton::clicked, this, &MainWindow::cancelRequested);
    connect(m_discoverButton,
            &QPushButton::clicked,
            this,
            &MainWindow::openDiscoverRequested);
}

void MainWindow::showAndActivate()
{
    show();
    raise();
    activateWindow();
}

void MainWindow::setBusyState(UpdateStatus status, const QString &details)
{
    UpdateResult result;
    result.status = status;
    result.details = details;
    m_titleLabel->setText(updateStatusTitle(status));
    m_descriptionLabel->setText(updateStatusDescription(result));
    m_progress->show();
    m_table->hide();
    updateControls(true, false);
}

void MainWindow::setResult(const UpdateResult &result)
{
    m_titleLabel->setText(updateStatusTitle(result.status));
    m_descriptionLabel->setText(updateStatusDescription(result));
    m_progress->hide();
    populatePackages(result.packages);
    updateControls(false, hasAvailableUpdates(result));

    if (result.checkedAt.isValid()) {
        m_lastCheckedLabel->setText(
            tr("Última verificação: %1")
                .arg(QLocale().toString(result.checkedAt.toLocalTime(), QLocale::ShortFormat)));
    }

    const QString iconName = hasAvailableUpdates(result)
        ? QStringLiteral("software-update-available")
        : (result.status == UpdateStatus::NoUpdates ? QStringLiteral("emblem-checked")
                                                     : QStringLiteral("dialog-warning"));
    m_iconLabel->setPixmap(QIcon::fromTheme(iconName).pixmap(
        style()->pixelMetric(QStyle::PM_LargeIconSize)));
}

void MainWindow::populatePackages(const QVector<PackageUpdate> &packages)
{
    m_table->setRowCount(packages.size());
    for (qsizetype row = 0; row < packages.size(); ++row) {
        const auto &package = packages.at(row);
        auto *nameItem = new QTableWidgetItem(package.name);
        if (package.security) {
            nameItem->setIcon(QIcon::fromTheme(QStringLiteral("security-high")));
            nameItem->setToolTip(tr("Atualização de segurança"));
        }
        m_table->setItem(static_cast<int>(row), 0, nameItem);
        m_table->setItem(static_cast<int>(row), 1, new QTableWidgetItem(package.version));
        m_table->setItem(static_cast<int>(row), 2, new QTableWidgetItem(package.architecture));
        m_table->setItem(static_cast<int>(row), 3, new QTableWidgetItem(package.summary));
    }
    m_table->setVisible(!packages.isEmpty());
}

void MainWindow::updateControls(bool busy, bool updatesAvailable)
{
    m_checkButton->setEnabled(!busy);
    m_cancelButton->setVisible(busy);
    m_discoverButton->setVisible(!busy && updatesAvailable);
}
