#include "update_types.h"

#include <QCoreApplication>

namespace {
QString tr(const char *text)
{
    return QCoreApplication::translate("UpdateStatus", text);
}
}

bool isTerminalStatus(UpdateStatus status)
{
    switch (status) {
    case UpdateStatus::Idle:
    case UpdateStatus::RefreshingCache:
    case UpdateStatus::Checking:
        return false;
    case UpdateStatus::NoUpdates:
    case UpdateStatus::UpdatesAvailable:
    case UpdateStatus::BackendUnavailable:
    case UpdateStatus::NetworkUnavailable:
    case UpdateStatus::Busy:
    case UpdateStatus::Cancelled:
    case UpdateStatus::Error:
        return true;
    }
    return true;
}

bool hasAvailableUpdates(const UpdateResult &result)
{
    return result.status == UpdateStatus::UpdatesAvailable && !result.packages.isEmpty();
}

QString updateStatusTitle(UpdateStatus status)
{
    switch (status) {
    case UpdateStatus::Idle:
        return tr("Atualizações do sistema");
    case UpdateStatus::RefreshingCache:
        return tr("Atualizando informações dos repositórios...");
    case UpdateStatus::Checking:
        return tr("Procurando atualizações...");
    case UpdateStatus::NoUpdates:
        return tr("O sistema está atualizado");
    case UpdateStatus::UpdatesAvailable:
        return tr("Atualizações disponíveis");
    case UpdateStatus::BackendUnavailable:
        return tr("Serviço de atualizações indisponível");
    case UpdateStatus::NetworkUnavailable:
        return tr("Sem conexão de rede");
    case UpdateStatus::Busy:
        return tr("O gerenciador de pacotes está ocupado");
    case UpdateStatus::Cancelled:
        return tr("Verificação cancelada");
    case UpdateStatus::Error:
        return tr("Não foi possível verificar atualizações");
    }
    return tr("Estado desconhecido");
}

QString updateStatusDescription(const UpdateResult &result)
{
    if (!result.details.simplified().isEmpty()) {
        return result.details.simplified();
    }

    switch (result.status) {
    case UpdateStatus::Idle:
        return tr("Verifique se há novas atualizações para este computador.");
    case UpdateStatus::RefreshingCache:
        return tr("Obtendo as informações mais recentes dos repositórios.");
    case UpdateStatus::Checking:
        return tr("Consultando o serviço PackageKit.");
    case UpdateStatus::NoUpdates:
        return tr("Nenhum pacote precisa ser atualizado agora.");
    case UpdateStatus::UpdatesAvailable:
        if (result.packages.size() == 1) {
            return tr("1 pacote pode ser atualizado.");
        }
        return tr("%1 pacotes podem ser atualizados.").arg(result.packages.size());
    case UpdateStatus::BackendUnavailable:
        return tr("O PackageKit não está disponível nesta sessão.");
    case UpdateStatus::NetworkUnavailable:
        return tr("Conecte-se a uma rede e tente novamente.");
    case UpdateStatus::Busy:
        return tr("Aguarde a conclusão da outra operação e tente novamente.");
    case UpdateStatus::Cancelled:
        return tr("A operação foi interrompida sem alterar o sistema.");
    case UpdateStatus::Error:
        return tr("O serviço de atualizações retornou um erro inesperado.");
    }
    return {};
}

UpdateResult resultForPackages(QVector<PackageUpdate> packages)
{
    UpdateResult result;
    result.status = packages.isEmpty() ? UpdateStatus::NoUpdates : UpdateStatus::UpdatesAvailable;
    result.packages = std::move(packages);
    result.checkedAt = QDateTime::currentDateTimeUtc();
    return result;
}

UpdateResult errorResult(UpdateStatus status, QString details)
{
    UpdateResult result;
    result.status = status;
    result.details = std::move(details);
    result.checkedAt = QDateTime::currentDateTimeUtc();
    return result;
}
