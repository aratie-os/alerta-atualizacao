#pragma once

#include "update_types.h"

#include <QObject>

class NotificationService final : public QObject
{
    Q_OBJECT

public:
    explicit NotificationService(QObject *parent = nullptr);

    void notify(const UpdateResult &result, bool interactive);

signals:
    void showWindowRequested();
    void openDiscoverRequested();
};
