#pragma once

#include <QObject>

#include <memory>

class QLocalServer;
class QLockFile;

class SingleInstance final : public QObject
{
    Q_OBJECT

public:
    explicit SingleInstance(QString applicationId, QObject *parent = nullptr);
    ~SingleInstance() override;

    [[nodiscard]] bool acquire();
    [[nodiscard]] bool activateExisting();

signals:
    void activationRequested();

private:
    QString m_serverName;
    std::unique_ptr<QLockFile> m_lock;
    std::unique_ptr<QLocalServer> m_server;
};
