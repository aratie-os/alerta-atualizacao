#include "notification_service.h"

#include <KNotification>

NotificationService::NotificationService(QObject *parent)
    : QObject(parent)
{
}

void NotificationService::notify(const UpdateResult &result, bool interactive)
{
    if (!hasAvailableUpdates(result) && !interactive) {
        return;
    }

    auto *notification = new KNotification(
        hasAvailableUpdates(result) ? QStringLiteral("updatesAvailable")
                                    : QStringLiteral("updateCheckResult"));
    notification->setComponentName(QStringLiteral("system-upgrade"));
    notification->setTitle(updateStatusTitle(result.status));
    notification->setText(updateStatusDescription(result));
    notification->setIconName(hasAvailableUpdates(result)
                                  ? QStringLiteral("software-update-available")
                                  : QStringLiteral("system-software-update"));

    auto *defaultAction = notification->addDefaultAction(tr("Mostrar detalhes"));
    connect(defaultAction,
            &KNotificationAction::activated,
            this,
            &NotificationService::showWindowRequested);

    if (hasAvailableUpdates(result)) {
        auto *discoverAction = notification->addAction(tr("Abrir Discover"));
        connect(discoverAction,
                &KNotificationAction::activated,
                this,
                &NotificationService::openDiscoverRequested);
    }
    notification->sendEvent();
}
