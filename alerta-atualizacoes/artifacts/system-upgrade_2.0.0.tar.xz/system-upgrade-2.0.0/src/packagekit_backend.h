#pragma once

#include "update_types.h"

#include <QObject>
#include <QPointer>

namespace PackageKit {
class Transaction;
}

class PackageKitBackend final : public QObject
{
    Q_OBJECT

public:
    explicit PackageKitBackend(QObject *parent = nullptr);

    [[nodiscard]] bool isRunning() const;

public slots:
    void checkForUpdates(bool refreshCache = true);
    void cancel();

signals:
    void stateChanged(UpdateStatus status, const QString &details);
    void resultReady(const UpdateResult &result);

private:
    enum class Operation { None, Refresh, Query };

    void startRefresh();
    void startQuery();
    void attachCommonSignals(PackageKit::Transaction *transaction, Operation operation);
    void finishWithError(UpdateStatus status, const QString &details);
    void clearTransaction();

    QPointer<PackageKit::Transaction> m_transaction;
    QVector<PackageUpdate> m_packages;
    QString m_errorDetails;
    UpdateStatus m_errorStatus = UpdateStatus::Error;
};
