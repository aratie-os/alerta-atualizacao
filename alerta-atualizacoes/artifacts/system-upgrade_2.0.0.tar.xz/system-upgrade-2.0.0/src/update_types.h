#pragma once

#include <QDateTime>
#include <QMetaType>
#include <QString>
#include <QVector>

enum class UpdateStatus {
    Idle,
    RefreshingCache,
    Checking,
    NoUpdates,
    UpdatesAvailable,
    BackendUnavailable,
    NetworkUnavailable,
    Busy,
    Cancelled,
    Error,
};

struct PackageUpdate {
    QString packageId;
    QString name;
    QString version;
    QString architecture;
    QString summary;
    bool security = false;

};

struct UpdateResult {
    UpdateStatus status = UpdateStatus::Idle;
    QVector<PackageUpdate> packages;
    QString details;
    QDateTime checkedAt;

};

[[nodiscard]] bool isTerminalStatus(UpdateStatus status);
[[nodiscard]] bool hasAvailableUpdates(const UpdateResult &result);
[[nodiscard]] QString updateStatusTitle(UpdateStatus status);
[[nodiscard]] QString updateStatusDescription(const UpdateResult &result);
[[nodiscard]] UpdateResult resultForPackages(QVector<PackageUpdate> packages);
[[nodiscard]] UpdateResult errorResult(UpdateStatus status, QString details = {});

Q_DECLARE_METATYPE(UpdateStatus)
Q_DECLARE_METATYPE(PackageUpdate)
Q_DECLARE_METATYPE(UpdateResult)
