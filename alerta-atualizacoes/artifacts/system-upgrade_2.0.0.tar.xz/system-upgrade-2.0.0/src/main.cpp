#include "main_window.h"
#include "notification_service.h"
#include "packagekit_backend.h"
#include "single_instance.h"
#include "tray_controller.h"

#include <QApplication>
#include <QCommandLineParser>
#include <QLoggingCategory>
#include <QMessageBox>
#include <QProcess>
#include <QTimer>

#include <unistd.h>

Q_LOGGING_CATEGORY(logApplication, "system-upgrade.application")

namespace {
bool openDiscover(QWidget *parent)
{
    const bool started = QProcess::startDetached(QStringLiteral("plasma-discover"),
                                                  {QStringLiteral("--mode=Update")});
    if (!started && parent) {
        QMessageBox::warning(parent,
                             QObject::tr("Discover indisponível"),
                             QObject::tr("Não foi possível iniciar o Plasma Discover."));
    }
    if (!started) {
        qCWarning(logApplication) << "Could not start plasma-discover";
    }
    return started;
}
}

int main(int argc, char *argv[])
{
    QApplication application(argc, argv);
    QApplication::setApplicationName(QStringLiteral("system-upgrade"));
    QApplication::setApplicationDisplayName(QObject::tr("Atualizações do sistema"));
    QApplication::setOrganizationName(QStringLiteral("Aratie OS"));
    QApplication::setOrganizationDomain(QStringLiteral("aratie-os.github.io"));
    QApplication::setDesktopFileName(QStringLiteral("system-upgrade"));
    QApplication::setQuitOnLastWindowClosed(false);

    QCommandLineParser parser;
    parser.setApplicationDescription(QObject::tr("Verificador de atualizações para Plasma"));
    parser.addHelpOption();
    parser.addVersionOption();
    const QCommandLineOption guiOption(QStringLiteral("gui"),
                                        QObject::tr("Mostra a janela principal."));
    const QCommandLineOption backgroundOption(QStringLiteral("background"),
                                               QObject::tr("Verifica em segundo plano."));
    const QCommandLineOption noRefreshOption(QStringLiteral("no-refresh"),
                                              QObject::tr("Usa o cache atual do PackageKit."));
    parser.addOption(guiOption);
    parser.addOption(backgroundOption);
    parser.addOption(noRefreshOption);
    parser.process(application);

    if (::geteuid() == 0) {
        qCCritical(logApplication) << "Refusing to run the graphical application as root";
        return 77;
    }

    SingleInstance instance(QStringLiteral("system-upgrade"));
    if (!instance.acquire()) {
        if (!instance.activateExisting()) {
            qCWarning(logApplication) << "Another instance owns the lock but could not be activated";
            return 1;
        }
        return 0;
    }

    const bool background = parser.isSet(backgroundOption);
    const bool showInitially = parser.isSet(guiOption) || !background;

    MainWindow window;
    window.winId();
    PackageKitBackend backend;
    NotificationService notifications;
    TrayController tray(&window);

    QObject::connect(&instance, &SingleInstance::activationRequested, &window, &MainWindow::showAndActivate);
    QObject::connect(&window, &MainWindow::checkRequested, &backend, &PackageKitBackend::checkForUpdates);
    QObject::connect(&tray, &TrayController::checkRequested, &backend, &PackageKitBackend::checkForUpdates);
    QObject::connect(&window, &MainWindow::cancelRequested, &backend, &PackageKitBackend::cancel);
    QObject::connect(&backend, &PackageKitBackend::stateChanged, &window, &MainWindow::setBusyState);
    QObject::connect(&backend, &PackageKitBackend::stateChanged, &tray, &TrayController::setBusyState);
    QObject::connect(&backend, &PackageKitBackend::resultReady, &window, &MainWindow::setResult);
    QObject::connect(&backend, &PackageKitBackend::resultReady, &tray, &TrayController::setResult);
    QObject::connect(&notifications,
                     &NotificationService::showWindowRequested,
                     &window,
                     &MainWindow::showAndActivate);

    const auto discoverLauncher = [&window] { openDiscover(&window); };
    QObject::connect(&window, &MainWindow::openDiscoverRequested, &application, discoverLauncher);
    QObject::connect(&tray, &TrayController::openDiscoverRequested, &application, discoverLauncher);
    QObject::connect(&notifications,
                     &NotificationService::openDiscoverRequested,
                     &application,
                     discoverLauncher);
    QObject::connect(&tray, &TrayController::quitRequested, &application, &QApplication::quit);

    QObject::connect(&backend,
                     &PackageKitBackend::resultReady,
                     &application,
                     [&](const UpdateResult &result) {
                         notifications.notify(result, showInitially);
                         if (background && !hasAvailableUpdates(result)) {
                             QTimer::singleShot(250, &application, &QApplication::quit);
                         }
                     });

    if (showInitially) {
        window.showAndActivate();
    }
    QTimer::singleShot(0,
                       &backend,
                       [&backend, refresh = !parser.isSet(noRefreshOption)] {
                           backend.checkForUpdates(refresh);
                       });

    return application.exec();
}
