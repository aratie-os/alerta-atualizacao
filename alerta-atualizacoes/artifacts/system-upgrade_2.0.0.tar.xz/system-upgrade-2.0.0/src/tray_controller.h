#pragma once

#include "update_types.h"

#include <QObject>

class KStatusNotifierItem;
class MainWindow;

class TrayController final : public QObject
{
    Q_OBJECT

public:
    explicit TrayController(MainWindow *window, QObject *parent = nullptr);

public slots:
    void setResult(const UpdateResult &result);
    void setBusyState(UpdateStatus status, const QString &details);

signals:
    void checkRequested(bool refreshCache);
    void openDiscoverRequested();
    void quitRequested();

private:
    KStatusNotifierItem *m_item = nullptr;
};
