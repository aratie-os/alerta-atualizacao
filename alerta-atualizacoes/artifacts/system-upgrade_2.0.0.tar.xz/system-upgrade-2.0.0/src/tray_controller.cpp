#include "tray_controller.h"

#include "main_window.h"

#include <KStatusNotifierItem>

#include <QAction>
#include <QIcon>
#include <QMenu>

TrayController::TrayController(MainWindow *window, QObject *parent)
    : QObject(parent)
    , m_item(new KStatusNotifierItem(QStringLiteral("system-upgrade"), this))
{
    m_item->setCategory(KStatusNotifierItem::SystemServices);
    m_item->setTitle(tr("Atualizações do sistema"));
    m_item->setIconByName(QStringLiteral("system-software-update"));
    m_item->setStatus(KStatusNotifierItem::Passive);
    m_item->setAssociatedWindow(window->windowHandle());

    auto *menu = new QMenu(window);
    QAction *showAction = menu->addAction(QIcon::fromTheme(QStringLiteral("system-software-update")),
                                           tr("Abrir"));
    QAction *checkAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")),
                                            tr("Verificar agora"));
    QAction *discoverAction = menu->addAction(QIcon::fromTheme(QStringLiteral("plasmadiscover")),
                                               tr("Abrir Discover"));
    menu->addSeparator();
    QAction *quitAction = menu->addAction(QIcon::fromTheme(QStringLiteral("application-exit")),
                                           tr("Sair"));
    m_item->setContextMenu(menu);

    connect(showAction, &QAction::triggered, window, &MainWindow::showAndActivate);
    connect(checkAction, &QAction::triggered, this, [this] { emit checkRequested(true); });
    connect(discoverAction, &QAction::triggered, this, &TrayController::openDiscoverRequested);
    connect(quitAction, &QAction::triggered, this, &TrayController::quitRequested);
}

void TrayController::setResult(const UpdateResult &result)
{
    m_item->setToolTip(QStringLiteral("system-software-update"),
                       updateStatusTitle(result.status),
                       updateStatusDescription(result));
    if (hasAvailableUpdates(result)) {
        m_item->setIconByName(QStringLiteral("software-update-available"));
        m_item->setAttentionIconByName(QStringLiteral("software-update-urgent"));
        m_item->setStatus(KStatusNotifierItem::NeedsAttention);
    } else {
        m_item->setIconByName(QStringLiteral("system-software-update"));
        m_item->setStatus(KStatusNotifierItem::Passive);
    }
}

void TrayController::setBusyState(UpdateStatus status, const QString &details)
{
    UpdateResult result;
    result.status = status;
    result.details = details;
    m_item->setToolTip(QStringLiteral("system-software-update"),
                       updateStatusTitle(status),
                       updateStatusDescription(result));
    m_item->setStatus(KStatusNotifierItem::Active);
}
