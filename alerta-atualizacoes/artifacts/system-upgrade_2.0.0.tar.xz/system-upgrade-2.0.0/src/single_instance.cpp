#include "single_instance.h"

#include <QCoreApplication>
#include <QDir>
#include <QLocalServer>
#include <QLocalSocket>
#include <QLockFile>
#include <QLoggingCategory>
#include <QStandardPaths>

#include <unistd.h>

Q_LOGGING_CATEGORY(logSingleInstance, "system-upgrade.single-instance")

SingleInstance::SingleInstance(QString applicationId, QObject *parent)
    : QObject(parent)
{
    QString runtimeDirectory = QStandardPaths::writableLocation(QStandardPaths::RuntimeLocation);
    if (runtimeDirectory.isEmpty()) {
        runtimeDirectory = QStandardPaths::writableLocation(QStandardPaths::TempLocation);
    }
    const QString userSuffix = QString::number(static_cast<qulonglong>(::getuid()));
    m_serverName = applicationId + QLatin1Char('-') + userSuffix;
    m_lock = std::make_unique<QLockFile>(QDir(runtimeDirectory).filePath(m_serverName + ".lock"));
}

SingleInstance::~SingleInstance() = default;

bool SingleInstance::acquire()
{
    if (!m_lock->tryLock()) {
        qCWarning(logSingleInstance) << "Could not acquire instance lock" << m_lock->fileName()
                                     << "error" << m_lock->error();
        return false;
    }

    m_server = std::make_unique<QLocalServer>();
    m_server->setSocketOptions(QLocalServer::UserAccessOption);
    QLocalServer::removeServer(m_serverName);
    if (!m_server->listen(m_serverName)) {
        qCWarning(logSingleInstance) << "Could not listen on local activation socket"
                                     << m_serverName << m_server->errorString();
        m_server.reset();
        return true;
    }

    connect(m_server.get(), &QLocalServer::newConnection, this, [this] {
        while (QLocalSocket *socket = m_server->nextPendingConnection()) {
            connect(socket, &QLocalSocket::readyRead, this, [this, socket] {
                if (socket->readAll().startsWith("activate")) {
                    emit activationRequested();
                }
                socket->disconnectFromServer();
            });
            connect(socket, &QLocalSocket::disconnected, socket, &QObject::deleteLater);
        }
    });
    return true;
}

bool SingleInstance::activateExisting()
{
    QLocalSocket socket;
    socket.connectToServer(m_serverName, QIODevice::WriteOnly);
    if (!socket.waitForConnected(1000)) {
        return false;
    }
    socket.write("activate\n");
    if (!socket.waitForBytesWritten(1000)) {
        return false;
    }
    socket.disconnectFromServer();
    return true;
}
