#pragma once

#include "update_types.h"

#include <PackageKit/transaction.h>

[[nodiscard]] UpdateStatus packageKitErrorStatus(PackageKit::Transaction::Error error);
